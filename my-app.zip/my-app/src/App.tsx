import './App.css';
import Parent from './components/Parent';

function App() {
  return (
    <Parent />
  );
}

export default App;
