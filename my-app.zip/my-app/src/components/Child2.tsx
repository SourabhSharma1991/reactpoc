import React from 'react';
import { Typography, Box } from '@mui/material';

interface Child2Props {
  message: string;
}

const Child2: React.FC<Child2Props> = ({ message }) => {
  return (
    <Box mt={2}>
      <Typography variant="h6" gutterBottom>
        Child2 Received:
      </Typography>
      <Typography variant="body1">{message || 'No message yet.'}</Typography>
    </Box>
  );
};

export default Child2;
