import React from 'react';
import { TextField, Box } from '@mui/material';

interface Child1Props {
  setMessage: (value: string) => void;
}

const Child1: React.FC<Child1Props> = ({ setMessage }) => {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setMessage(e.target.value);
  };

  return (
    <Box my={2}>
      <TextField
        label="Enter Message"
        variant="outlined"
        fullWidth
        onChange={handleChange}
      />
    </Box>
  );
};

export default Child1;
