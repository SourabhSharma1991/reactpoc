import React, { useState } from 'react';
import Child1 from './Child1';
import Child2 from './Child2';
import { Container, Typography, Box } from '@mui/material';

const Parent: React.FC = () => {
  const [message, setMessage] = useState<string>('');

  return (
    <Container maxWidth="sm">
      <Box my={4}>
        <Typography variant="h4" gutterBottom>
          Parent Component
        </Typography>
        <Child1 setMessage={setMessage} />
        <Child2 message={message} />
      </Box>
    </Container>
  );
};

export default Parent;
